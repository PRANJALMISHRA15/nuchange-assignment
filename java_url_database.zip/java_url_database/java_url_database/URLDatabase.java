package java_url_database;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class URLDatabase {
    private Map<String, URLData> database = new HashMap<>();
    private static final String DATABASE_FILE = "url_database.txt";

    public URLDatabase() {
        loadDatabaseFromFile();
    }

    public String storeURL(String url) {
        String shortKey = generateShortKey();
        URLData urlData = new URLData(url, shortKey);
        database.put(shortKey, urlData);
        saveDatabaseToFile();
        return shortKey;
    }

    public String getShortKey(String url) {
        for (URLData urlData : database.values()) {
            if (urlData.getUrl().equals(url)) {
                urlData.incrementCount();
                saveDatabaseToFile();
                return urlData.getShortKey();
            }
        }
        return null;
    }

    public int getCount(String url) {
        for (URLData urlData : database.values()) {
            if (urlData.getUrl().equals(url)) {
                return urlData.getCount();
            }
        }
        return -1;
    }

    public Map<String, Integer> getAllURLs() {
        Map<String, Integer> result = new HashMap<>();
        for (Map.Entry<String, URLData> entry : database.entrySet()) {
            result.put(entry.getKey(), entry.getValue().getCount());
        }
        return result;
    }

    private String generateShortKey() {
        // Generate short UID using UUID
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private void loadDatabaseFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATABASE_FILE))) {
            database = (Map<String, URLData>) ois.readObject();
        } catch (FileNotFoundException e) {
            // Ignore if the file doesn't exist yet
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveDatabaseToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATABASE_FILE))) {
            oos.writeObject(database);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
