package java_url_database;

import java.io.Serializable;

public class URLData implements Serializable {
    private String url;
    private String shortKey;
    private int count;

    public URLData(String url, String shortKey) {
        this.url = url;
        this.shortKey = shortKey;
        this.count = 0;
    }

    public String getShortKey() {
        return shortKey;
    }

    public String getUrl() {
        return url;
    }

    public int getCount() {
        return count;
    }

    public void incrementCount() {
        this.count++;
    }
}

