package java_url_database;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        URLDatabase urlDatabase = new URLDatabase();
        CommandProcessor commandProcessor = new CommandProcessor(urlDatabase);

        Scanner scanner = new Scanner(System.in);

        System.out.println("To start the program: run java url database.");

        while (true) {
            System.out.print("Enter command: ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                System.out.println("Exiting program...");
                break;
            }

            String[] parts = input.split(" ");
            if (parts.length >= 2) {
                String command = parts[0];
                String parameter = parts[1];
                String result = commandProcessor.processCommand(command, parameter);
                System.out.println(result);
            } else {
                System.out.println("Invalid input. Please enter a valid command.");
            }
        }

        scanner.close();
    }
}

