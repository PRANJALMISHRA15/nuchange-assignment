package java_url_database;

import java.util.Map;

public class CommandProcessor {
    private URLDatabase urlDatabase;

    public CommandProcessor(URLDatabase urlDatabase) {
        this.urlDatabase = urlDatabase;
    }

    public String processCommand(String command, String parameter) {
        switch (command.toLowerCase()) {
            case "storeurl":
                return urlDatabase.storeURL(parameter);
            case "get":
                return urlDatabase.getShortKey(parameter);
            case "count":
                return String.valueOf(urlDatabase.getCount(parameter));
            case "list":
                return toJSON(urlDatabase.getAllURLs());
            default:
                return "Invalid command";
        }
    }

    private String toJSON(Map<String, Integer> data) {
        // Convert data to JSON format
        StringBuilder json = new StringBuilder("{");
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            json.append("\"").append(entry.getKey()).append("\":").append(entry.getValue()).append(",");
        }
        if (json.length() > 1) {
            json.deleteCharAt(json.length() - 1); // Remove the trailing comma
        }
        json.append("}");
        return json.toString();
    }
}
